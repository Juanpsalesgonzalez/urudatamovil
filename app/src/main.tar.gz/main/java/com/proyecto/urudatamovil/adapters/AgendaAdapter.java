package com.proyecto.urudatamovil.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.proyecto.urudatamovil.R;
import com.proyecto.urudatamovil.objects.Agenda;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by juan on 20/08/15.
 */
public class AgendaAdapter extends ArrayAdapter<Agenda> {

    private ArrayList<Agenda> agendaAL;
    private final Context context;

    public AgendaAdapter(Context c, List<Agenda> model ){
        super(c, R.layout.item_lista_pet, model);
        this.context = c;
        this.agendaAL = (ArrayList) model;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.item_lista_assignement, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.firstLine);
        Agenda a= getItem(position);
        String line = a.getDia_semana() + " - " + a.getHora_entrada() + " - " + a.getHora_salida();
        textView.setText(line);

        return rowView;
    }


}

