package com.proyecto.urudatamovil.objects;

/**
 * Created by juan on 20/08/15.
 */
public class Agenda {

    private String dia_semana;
    private String hora_entrada;
    private String hora_salida;
    private String cliente;
    private String direccion;

    public Agenda(String dia_s, String hora_e, String hora_s,
                  String cli, String dir) {
        dia_semana=dia_s;
        hora_entrada=hora_e;
        hora_salida=hora_s;
        cliente=cli;
        direccion=dir;
    }

    public String getDia_semana() {
        return dia_semana;
    }
    public void setDia_semana(String dia_semana) {
        this.dia_semana = dia_semana;
    }
    public String getHora_entrada() {
        return hora_entrada;
    }
    public void setHora_entrada(String hora_entrada) {
        this.hora_entrada = hora_entrada;
    }
    public String getHora_salida() {
        return hora_salida;
    }
    public void setHora_salida(String hora_salida) {
        this.hora_salida = hora_salida;
    }
    public String getCliente() {
        return cliente;
    }
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }


}

