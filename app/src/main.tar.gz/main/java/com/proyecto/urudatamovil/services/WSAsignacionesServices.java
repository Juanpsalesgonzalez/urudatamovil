package com.proyecto.urudatamovil.services;

import com.proyecto.urudatamovil.objects.Agenda;
import com.proyecto.urudatamovil.utils.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.http.ContentCodingType;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 * Created by juan on 20/08/15.
 */
public class WSAsignacionesServices {

    public ArrayList<Agenda> listaAsignaciones(String user,String  cookie){


        String url = Constants.URL_LIST_ASIG+"?user=" + user;

        RestTemplate rT = new RestTemplate(true);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Cookie", cookie);
        headers.set("Content-type", "application/x-www-form-urlencoded");
        headers.setContentEncoding(ContentCodingType.ALL);
        HttpEntity requestEntity = new HttpEntity(headers);
        ResponseEntity<ArrayList> response = null;
        rT.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        try {
            response = rT.exchange(url, HttpMethod.GET, requestEntity, ArrayList.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        if (response == null) {
            System.out.println("Response NULL");
            //return null;
        }
        ArrayList<Agenda> agendaAL = responseToArray(response);
        return agendaAL;
    }
    public ArrayList<Agenda> responseToArray(ResponseEntity<ArrayList> response) {

        ArrayList agendaBody = response.getBody();
        JSONArray agJSONArray = new JSONArray(agendaBody);
        ArrayList<Agenda> agendas = new ArrayList<>();


        for (int i = 0; i < agJSONArray.length(); i++) {
            try {
                LinkedHashMap<String, Object> agHashMap = (LinkedHashMap<String, Object>) agJSONArray.get(i);
                Agenda a = hashMapToAgenda(agHashMap);
                agendas.add(i, a);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return agendas;
    }

    public Agenda hashMapToAgenda(LinkedHashMap<String, Object> agHashMap){

        String dia_semana, hora_entrada, hora_salida, cliente, direccion;
        dia_semana=(String) agHashMap.get("dia_semana");
        hora_entrada=(String) agHashMap.get("hora_entrada");
        hora_salida=(String) agHashMap.get("hora_salida");
        cliente=(String) agHashMap.get("cliente");
        direccion=(String) agHashMap.get("direccion");

        Agenda ag = new Agenda(dia_semana, hora_entrada, hora_salida, cliente, direccion);
        return ag;
    }
}
