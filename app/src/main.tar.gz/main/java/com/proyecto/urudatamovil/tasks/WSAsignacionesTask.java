package com.proyecto.urudatamovil.tasks;

import android.os.AsyncTask;

import com.proyecto.urudatamovil.activities.ListAsignacionesActivity;
import com.proyecto.urudatamovil.objects.Agenda;
import com.proyecto.urudatamovil.services.WSAsignacionesServices;
import com.proyecto.urudatamovil.services.WSLoginServices;

import java.util.ArrayList;

/**
 * Created by juan on 20/08/15.
 */
public class WSAsignacionesTask extends AsyncTask<String,String,ArrayList<Agenda>>{

    private ListAsignacionesActivity actividad;
    private WSLoginServices wsLoginServices ;
    private WSAsignacionesServices wsAsignacionesServices;

    public WSAsignacionesTask(com.proyecto.urudatamovil.activities.ListAsignacionesActivity a){
        actividad=a;
        wsLoginServices = new WSLoginServices();
        wsAsignacionesServices = new WSAsignacionesServices();
    }

    public ArrayList<Agenda> doInBackground(String ... params){

        String user, pass,cookie;
        ArrayList<Agenda> listaAg = new ArrayList<>();

        user=params[0];
        pass=params[1];

        cookie= wsLoginServices.getCookie(wsLoginServices.loginToWS(user, pass));
        if (cookie ==null){
            return null;
        }
        listaAg= wsAsignacionesServices.listaAsignaciones(user, cookie);

        return listaAg;


    }
    @Override
    protected void onPostExecute(ArrayList<Agenda> a) {
        if (a == null) {
            actividad.confirmTaskFinished(null);
        } else
            actividad.setModel(a);
    }

}
